import { Component } from "react";

export default class TodoList extends Component{




    render() {
        return (
            <h1>Todo List</h1>
        )
        
    }
}